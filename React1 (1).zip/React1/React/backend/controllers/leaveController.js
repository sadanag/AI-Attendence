// controllers/leaveController.js
import LeaveRequest from "../models/LeaveRequest.js";
import Employee from "../models/Employee.js";

export async function createLeaveRequest(req, res) {
  try {
    const { employeeId, fromDate, toDate, reason } = req.body;
    if (!employeeId || !fromDate || !toDate || !reason) {
      return res.status(400).json({ message: "employeeId, fromDate, toDate, reason are required" });
    }

    // Optional: ensure the requester is the same employee unless admin
    if (req.user.role !== "admin" && String(req.user._id) !== String(employeeId)) {
      return res.status(403).json({ message: "Forbidden" });
    }

    const employee = await Employee.findById(employeeId);
    if (!employee) return res.status(404).json({ message: "Employee not found" });

    const doc = await LeaveRequest.create({
      employeeId,
      fromDate: new Date(fromDate),
      toDate: new Date(toDate),
      reason
    });

    res.json({ message: "Leave request submitted", leaveRequest: doc });
  } catch (e) {
    res.status(500).json({ message: "Server error" });
  }
}
