// routes/leaveRoutes.js
import { Router } from "express";
import { auth } from "../middlewares/authMiddleware.js";
import { createLeaveRequest } from "../controllers/leaveController.js";

const router = Router();

// matches frontend: POST /leave-request
router.post("/leave-request", auth, createLeaveRequest);

export default router;
